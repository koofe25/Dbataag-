# Daba-Taag Android APK project (Phase 7D)

Mashruucan wuxuu ku duubayaa frontend-ka Daba-Taag gudaha Android WebView, wuxuuna leeyahay app icon u gaar ah. APK binary ah halkan lagama soo saarin sababtoo ah deegaanka diyaarinaya faylka ma laha Android SDK/Gradle build toolchain. GitHub Actions ayaa kuu dhisaya APK-ga marka aad repo-ga geliso.

## Sida APK loo helo
1. Ka fur GitHub oo samee repository cusub, tusaale `daba-taag-android`.
2. Soo geli dhammaan faylasha ZIP-kan (ha gelin ZIP-ga oo keliya; extract marka hore).
3. Fur tab-ka **Actions** oo dooro **Build Daba-Taag APK**.
4. Riix **Run workflow** haddii uusan iskiis u bilaaban.
5. Marka build-ku guuleysto, fur run-ka dhammaaday oo ka soo dejiso artifact-ka `Daba-Taag-Android-APK`.
6. Ka fur ZIP-ga artifact-ka; gudaha waxaa ku jira `app-debug.apk`. Ku rakib Android-ka adigoo oggolaanaya install-ka app-ka laga keenay source-kaas.

## Fiiro amni iyo farsamo
- APK-ga debug wuxuu ku habboon yahay tijaabo; Play Store ama qaybinta rasmi ah wuxuu u baahan yahay signing key release ah.
- APK-gu wuxuu ku shaqaynayaa kaydinta browser-ka ee app-ka. Xogta local-ka ah si toos ah uguma wadaaganto browser-ka caadiga ah ama telefoon kale.
- Backend/Supabase lama habayn. Haddii app-ka loo adeegsanayo shaqo dhab ah, waa in backend-ka, maamulka, login-ka iyo oggolaanshaha lagu adkeeyaa server-ka; ha ku tiirsanaan role/password ku kaydsan frontend-ka.
- Khariidado iyo adeegyo dibadeed waxay u baahan karaan internet.
