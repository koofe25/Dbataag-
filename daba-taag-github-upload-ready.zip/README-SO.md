# DABA-TAAG Android APK — GitHub Actions

ZIP-kan waxaa ku jira mashruuca Android-ka iyo workflow si GitHub Actions uu u dhiso APK. **Ha u gelin ZIP-kan GitHub sida hal fayl oo keliya**; marka hore Extract/Unzip, ka dib geli dhammaan faylasha iyo galalka gudaha repository-ga, si `.github/workflows/build-apk.yml` uu ugu jiro meesha ugu sarreysa ee repository-ga.

## Habka ugu fudud
1. GitHub ka samee repository cusub oo la yiraahdo `daba-taag-android`.
2. Soo dejiso ZIP-kan, kadib telefoonka/computer-ka ka dooro **Extract**.
3. Gudaha galka la soo saaray, dooro dhammaan faylasha iyo galalka (oo ay ku jirto `.github`) oo ku upload-garee repository-ga. Ha upload-gareyn ZIP-ka oo keliya, hana ku darin galka kore `daba-taag-android/` sida hal gal oo gudaha repo-ga ah.
4. Marka faylasha la geliyo, fur repository-ga **Actions**.
5. Dooro workflow-ga **Build Daba-Taag APK**, kadib taabo **Run workflow**. Haddii Actions uusan muuqan, hubi in `.github/workflows/build-apk.yml` uu yaallo root-ka repository-ga.
6. Marka shaqadu dhammaato oo calaamadda cagaaran muuqato, fur run-kaas oo hoos ugu dhaadhac **Artifacts**.
7. Soo dejiso `Daba-Taag-Android-APK.zip`, ka fur, kadib rakib `app-debug.apk` telefoonka Android-ka.

## Haddii telefoonku kuu diido upload-ka `.github`
Qaar ka mid ah file pickers-ka Android waxay qariyaan galalka ku bilaabma dhibic. Isticmaal app file manager oo muujiya hidden files, ama samee upload-ka kombiyuutar. Workflow-ga waa inuu ahaadaa waddadan saxda ah: `.github/workflows/build-apk.yml`.

## Fiiro muhiim ah
- APK-ga debug wuxuu ku habboon yahay tijaabo; qaybinta rasmiga ah waxay u baahan tahay release signing.
- App-ku wuxuu ku shaqeeyaa frontend-ka ku dhex jira Android WebView. Xogta browser-ka maxalliga ah si toos ah uguma wadaaganto qalab kale.
- Backend/Supabase lama xirin. Ka hor isticmaal ganacsi, ku xooji authentication, roles iyo kaydinta xogta server-ka.
